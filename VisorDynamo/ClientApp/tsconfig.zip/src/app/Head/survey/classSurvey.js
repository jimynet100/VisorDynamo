"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Survey = /** @class */ (function () {
    function Survey(idProyecto, idCorrelativo, resText, resNumero) {
        this.idCorrelativo = idProyecto;
        this.idCorrelativo = idCorrelativo;
        this.resText = resText;
        this.resNumero = resNumero;
    }
    return Survey;
}());
exports.Survey = Survey;
//# sourceMappingURL=classSurvey.js.map