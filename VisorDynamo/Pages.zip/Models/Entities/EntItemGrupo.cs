﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VisorDynamo.Models.Entities
{
    public class EntItemGrupo
    {
        public int idGrupo { get; set; }
        public string nombre { get; set; }
        public string fechaCreacion { get; set; }
        public string tipo { get; set; }
    }
}
