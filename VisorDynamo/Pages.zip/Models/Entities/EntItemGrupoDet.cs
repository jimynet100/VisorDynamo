﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VisorDynamo.Models.Entities
{
    public class EntItemGrupoDet
    {
        public EntItemGrupo grupo { get; set; }
        public string idSolicitud { get; set; }
    }
}
