﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VisorDynamo.Models.Entities
{
    public class EntSurvey
    {
            public int idProyecto { get; set; }
            public int idCorrelativo { get; set; }
            public string resText { get; set; }
            public string resNumero { get; set; }
    }
}
